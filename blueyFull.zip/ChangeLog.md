### Changes 

### TODO

* Implement hero full background with overlay for css, copy code from internet

See notebook for sketch ideas.

#### 11/30/2019
Figured out how to install wordpress in docker with mysql (seems to only work the first time and with mysql 5.7), may have to wait for startup.

* Got wordpress working in docker 
* Installed tailwindcss with hacky changes
* Basic Git repo